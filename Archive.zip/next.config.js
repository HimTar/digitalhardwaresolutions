module.exports = {
  env: {
    MONGO_URI:
      "mongodb+srv://Himanshu:abcd@1234@cluster0.kdtwe.mongodb.net/blog?retryWrites=true&w=majority",
  },
};
