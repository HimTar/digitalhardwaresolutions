export const addNewContactURL = "/api/contactus/add";
export const getAllContactsURL = "/api/contactus/get";
export const viewContactURL = "/api/contactus/view";

export const viewLandingPageURL = "/api/visit";
