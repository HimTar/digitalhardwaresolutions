let landing = 0;
let contact = 0;

export const addLanding = () => {
  landing + 1;
};

export const addContact = () => {
  contact + 1;
};

export const getLanding = () => {
  return landing;
};

export const getContact = () => {
  return contact;
};
